## Welcome-BOT(To GDG)

![Welcome-BOT(To GDG)](https://raw.githubusercontent.com/Tkd-Alex/Welcome-To-GDG/master/img/banner.jpg  "Welcome-BOT(To GDG)")

Welcome To **GDG** it's a simple telegram bot. 
His job is to say *"Welcome"* to new members of telegram group, and invite them to join the [GDG Catania Forum](http://www.forum.gdgcatania.org/).



#### What is a GDG (Google Developers Group) ?
>Google Developer Groups are for developers who are interested in Google's developer technology. A GDG can take many forms -- from just a few people getting together, to large gatherings with demos and tech talks, to events like code sprints and hackathons. As of March 2015, there are currently 600+ GDGs worldwide.

#### Configure Welcome To GDG in other telegram group
Despite this bot is designed for the GDG group you can easily download the bot and use it in any other group to welcome new users! That's how:

For execute the bot your system needs:

- python2
- python-pip

Install [*python-telegram-bot*](https://github.com/python-telegram-bot/python-telegram-bot) with pip 
```sh
pip install python-telegram-bot --upgrade
```

*Config:*
- Edit ***config/welcome_message.html*** with your welcome message.
- Rename ***config/token.conf.dist*** in ***config/token.conf*** and paste your token received from BotFather.







