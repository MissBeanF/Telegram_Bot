#!/bin/sh

mkdir -p logs

while (true)
do
	python2 main.py
done